module Text.Nagato.Models
( Freqs
  ,Props
)where
import Data.Map

type Freqs = Map String Int
type Props = Map String Float
